#ifndef ACTION_H
#define ACTION_H

#include <iostream>
#include <string>
#include "AliceinWonderland.h" // Include necessary headers
#include "Characters.h"
#include "Objects.h"

class Action {
    private:
    Characters::Alice * alice;
  
public:

Action(Characters::Alice * alice);

    int handlePickUp(std::string object);
};

#endif // ACTION_H
