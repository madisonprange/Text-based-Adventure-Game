#ifndef ALICEINWONDERLAND_H
#define ALICEINWONDERLAND_H

#include <iostream>
#include <string>
#include <utility>
#include "Action.h"
#include "Settings.h"
#include "control.h"
#include "Characters.h"
#include "Objects.h"

class AliceinWonderland {
public:
    void run();
    static void main();

private:
    int gameStart();
    void gameGoal();
    std::string gameDesc();

    // Add other member variables and functions as needed

};

#endif // ALICEINWONDERLAND_H
