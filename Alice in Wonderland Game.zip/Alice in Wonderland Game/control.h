#ifndef CONTROL_H
#define CONTROL_H

#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <algorithm>
#include "AliceinWonderland.h" // Include necessary headers
#include "Action.h"

class Control {
    private:
    Action * action;
public:
~Control();
Control(Characters:: Alice * alice);
    std::pair<int, std::string> actionCall();
};

#endif // CONTROL_H
