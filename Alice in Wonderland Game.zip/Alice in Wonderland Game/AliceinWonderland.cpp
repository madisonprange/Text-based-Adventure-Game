#include "AliceinWonderland.h"
#include "Objects.h" // Include other necessary headers
#include "Characters.h"
#include "control.h"
#include <iostream>

void AliceinWonderland::run() {
    AliceinWonderland aliceinwonderland;
        int start = gameStart();
        if (start == 1){
        Characters ::Alice alice =  Characters::Alice();
        Control control(&alice);
        Settings settings;


        bool hasShovel = true;
        bool hasBlanket = true;
        bool hasEatenCake = false;
        bool hasEatenPotion = false;
        Settings::Field field;
        Settings::Hole hole;

        string currentLocation = "field";
        // current inventory = emtpy
        aliceinwonderland.gameGoal();
        cout << field.getDescription() << endl;
        cout << aliceinwonderland.gameDesc() << endl;
        // Create an instance of the Field class
        Object ::Shovel shovel;
        shovel.desc();

        while (true)
        {

            pair<int, string> actionResult = control.actionCall();
            cout << "Action Type: " << actionResult.first << ", Action Details: " << actionResult.second << endl;

            int actionType = actionResult.first;                   // Extract the action type from the result
            string actionDetails = actionResult.second;            // Extract the action details from the result

            switch (actionType)
            {
            case 1: // Movement action
                cout << "Moving to: " << actionDetails << endl;
                currentLocation = actionDetails; // update the current location
                break;

            case 2:
                if (actionDetails == "shovel")
                {
                    hasShovel = true; // user does have the shove
                }
                //Object ::Blanket blanket;
                //blanket.desc();
                break;

            case 6:
                if (actionDetails == "blanket")
                {
                    hasBlanket = true; // user does have the blanket
                    // Add logic specific to picking up the blanket
                }
                // Common story progression after handling blanket action
                // The story progresses regardless of the user's action
                // Add your common story logic here
                break;
            case 3:
                if (actionDetails == "potion")
                {
                    cout << "drinking the potion..." << endl;
                    hasEatenPotion = false;
                }
                else if (actionDetails == "cake")
                {
                    hasEatenCake = true;
                }
                break;
            case 4: // Dig action
                if (currentLocation == "hole")
                {
                    if (hasShovel)
                    {
                        Object::Shovel shovel;
                        shovel.digging();
                    }
                    else
                    {
                        cout << "You do not have a shovel in your inventory." << endl;
                      
                        alice.displayInventory();
                    }
                }
                else
                {
                    cout << "You cannot dig a hole here." << endl;
                }
            case 5:
                if (currentLocation == "field" || currentLocation == "forest")
                {
                    if (hasBlanket)
                    {
                        Object::Blanket blanket;
                        blanket.sleeping();
                    }
                    else
                    {
                        cout << "You do not have a blanket in your inventory." << endl;
                        Characters ::Alice alice;
                        alice.displayInventory();
                    }
                }
                else
                {
                    cout << "You cannot sleep here." << endl;
                }
                break;

            case 7:
                if (actionDetails == "blanket")
                {
                    hasBlanket = true; // user does have the shovel
                }
                else
                {
                    hasBlanket = false;
                }
                break;
            }
        }

        //these if statements need to change


        // Check if game over conditions are met
        if (!hasEatenPotion || !hasEatenCake)
        {
            cout << "You failed to consume the potion or eat the cake. Game over!" << endl;
            // End the game
        }

        // Check if the user reached the rabbit hole
        if (currentLocation == "hole")
        {
            cout << "You fell into the rabbit hole!" << endl;
            // Handle encounter in the rabbit hole
            // Prompt user to consume potion or eat cake
            // Update game state accordingly
        }

        // Handle events, objects, characters, and storylines for wonderland
        if (currentLocation == "wonderland")
        {
            // Execute wonderland-specific logic
            // Handle events, objects, characters, and storylines unique to wonderland
        }

        // Handle events, objects, characters, and storylines for forest
        if (currentLocation == "forest")
        {
            // Execute forest-specific logic
            // Handle events, objects, characters, and storylines unique to the forest
        }

        // Check if the game should continue or end based on conditions
        // Add more conditions as needed
    }
    }

void AliceinWonderland::main() {
    AliceinWonderland alice;
    alice.run();
}

int AliceinWonderland::gameStart() {
    char userInput;
        cout << "** WELCOME TO THE ALICE IN WONDERLAND GAME **" << endl;
        cout << "Would you like to play? (Y/N): ";
        cin >> userInput;

        while (userInput != 'Y' && userInput != 'N')
        {
            cout << "Would you like to play? (Y/N): ";
            cin >> userInput;
        }

        if (userInput == 'N')
        {
            return -1; // End the program
        }

        if (userInput == 'Y')
        {
            return 1; // Start the game
        }
        return 0;
}

void AliceinWonderland::gameGoal() {
      cout << "You are playing the character Alice. The goal of this game is to survive to the end to become a winner of this adaptation of Alice in Wonderland." << endl;
        cout << "Your health levels are currently at 10. Beware, as this can change if you take dammage, get hungry or thirsty. If you lose your health, a message will pop up on the screen." << endl;
        cout << "You will have the oppurtunity to pick up objects. You can only pick up 4 objects at a time. There is a safe room that you are able to collect your objects. " << endl;
        cout << "You will be prompted for next actions. To go to a certain location, type go to (location). To pick up an object, type pick up (object)" << endl;
        cout << "Make smart choices and have a fun time playing!" << endl;
}

std::string AliceinWonderland::gameDesc() {
    string beginning = "On a warm summer's day, Alice was sitting by her sister on the field. ";
        beginning += "She was bored, and didn't seem to want to preoccupy her time. ";
        beginning += "However, she notices a white rabbit that begins speaking to itself, in the midst of running away. She decides to follow the rabbit.";
        return beginning;
}
