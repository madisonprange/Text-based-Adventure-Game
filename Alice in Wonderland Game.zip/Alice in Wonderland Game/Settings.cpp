#include "Settings.h"
using namespace std;

std::string Settings::Field::getDescription() {
    return "This field is large and is known to preoccupy many animals. It is filled with plants and flowers, such as daisies.";
}

std::string Settings::Hole::getDescription1() {
    return "The hole is dark and steep.";
}

void Settings::Hole::getDescription2() {
    Characters::Alice alice;
    std::cout << "As you start falling down the rabbit hole, you notice how far down it is. It feels as if you are falling forever. It is dark and you can hardly see anything." << std::endl;
    std::cout << "You hit the ground abruptly. Your health is now " << alice.getCurrentHealth() << std::endl;
    std::cout << "You get up, and look around what appears to be a room. In the corner of this room, you see a table." << std::endl;
    std::cout << "On this table, you see a small liquid that says drink me. You know your health is low, and that drinking can subside this. CAUTION: You cannot pick up these objects to store. They must remain in this room." << std::endl;
}

void Settings::Forest::getDescription1(){
    cout<< "The forest has many trees and plants. You decide to explore a little, admiring the nature around you." <<endl;
}


void Settings::RabbitHouse::getDescription1(){
    cout<<"You go in the direction of the tall, white house." <<endl;
    cout<< "As directed by the rabbit, you go into the house. It is quite a large house for a rabbit, and contains many objects."<<endl;
}

