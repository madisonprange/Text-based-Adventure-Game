#include "Node.h"


Node* Node::getHole() {
    return goHole;
}

Node* Node::getWonderland() {
    return goWonderland;
}

Node* Node::getForest() {
    return goForest;
}
