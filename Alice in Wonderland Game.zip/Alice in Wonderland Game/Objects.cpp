#include "Objects.h"
using namespace std;

void Object::Shovel::desc() {
    std::cout << "You have stumbled across an object: Shovel. A shovel can be used for: " << actions() << std::endl;
}

std::string Object::Shovel::actions() {
    return "digging.";
}

void Object::Shovel::digging() {
   Characters::Alice alice;
    std::cout << "Digging..." << std::endl;
    std::cout << "You cannot dig here. Your shovel broke in the process. You also lose one health." << std::endl;
    alice.removeFromInventory("shovel");
    alice.aliceHealth(-1);
    std::cout << "Your current health is: " << alice.getCurrentHealth() << std::endl;
}

void Object::Blanket::desc() {
    std::cout << "You have stumbled across an object: Blanket. A blanket can be used for: " << actions() << std::endl;
}

std::string Object::Blanket::actions() {
    return "sleep.";
}

void Object::Blanket::sleeping() {
     Characters::Alice alice;
    if (alice.getCurrentHealth() <= 10) {
        std::cout << "You cannot sleep now. Your health is already at 10." << std::endl;
    }
    else {
        std::cout << "You take a nap to boost energy levels." << std::endl;
        alice.aliceHealth(+2);
        std::cout << "Your current health is: " << alice.getCurrentHealth() << std::endl;
        std::cout << "After your nap, the blanket becomes dirty. You throw it away." << std::endl;
        alice.removeFromInventory("blanket");
    }
}

//should the next 3 be considered inventory objects
void Object::PotionandCake::drink() {
    std::cout << "You drink the liquid and become very tiny. You cannot stay like this to survive!" << std::endl;
}

void Object::PotionandCake::eat() {
    std::cout << "You eat the cake and grow VERY LARGE! How will you ever leave the hole?" << std::endl;
}

void Object::Fan::desc(){
    cout<<"The item the rabbit dropped is a: fan. A fan can be used for making you back to your normal size!" <<endl;
}

void Object::Fan::useFan(){
    cout<< "You used the fan to go back to a normal size." <<endl;
}

void Object::waterBottle::desc(){
    cout<< "You approach a small bottle filled with water." <<endl;
}

void Object::waterBottle::drink(){
    Characters::Alice alice;
    cout << "You drink from the watter bottle. This increases your health by 1. You finish the water so you can no longer use it." <<endl;
    alice.aliceHealth(+1);
    alice.removeFromInventory("water bottle");
}

void Object::carrotPlush :: luckyitem(){
    cout<< "You have picked up a lucky item! Collect up to 3 lucky items to become a super star winner!"<<endl; //add this to a seperate inventory
}
