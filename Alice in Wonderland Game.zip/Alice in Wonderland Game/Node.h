#include <algorithm> // Add this line to include the <algorithm> header
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <utility>
#include <limits>

// adding a game state method to update where the game is currently

using namespace std;
#ifndef NODE_H
#define NODE_H

class Node
{
private:
    Node *goHole;
    Node *goWonderland;
    Node *goForest;
    std::string roomName;

public:
    Node(std::string name, Node *hole, Node *wonderland, Node *forest) : roomName(name), goHole(hole), goWonderland(wonderland), goForest(forest) {}

    Node *getHole();

    Node *getWonderland();
    Node *getForest();
};
#endif // NODE_H