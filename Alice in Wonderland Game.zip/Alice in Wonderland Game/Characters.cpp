#include "Characters.h"

Characters::Alice::Alice() : health(10), node(nullptr) {}

Characters::Alice::Alice(Node* start) : node(start), health(10) {}

bool Characters::Alice::CanMoveHole() {
    return node->getHole() != nullptr;
}

void Characters::Alice::moveHole() {
    std::cout << "Alice fell into the hole.";
    node = node->getHole();
    aliceHealth(-5);
}

void Characters::Alice::aliceHealth(int healthChange) {
    health += healthChange;
    if (health <= 0) {
        std::cout << "Alice has lost all her health and the game is over." << std::endl;
        // You can add further logic here if needed
    }
    if (health == 10) {
        std::cout << "Your health is full." << std::endl;
    }
}

int Characters::Alice::getCurrentHealth() const {
    return health;
}

void Characters::Alice::addToInventory(const std::string& object) {
    if (inventory.size() > 4) {
        std::cout << "Your inventory is full. Drop an item or go to the safe room to store your items." << std::endl;
    }
    else {
        inventory.push_back(object);
    }
}

void Characters::Alice::removeFromInventory(const std::string& object) {
    auto it = std::find(inventory.begin(), inventory.end(), object);
    if (it != inventory.end()) {
        inventory.erase(it);
        std::cout << "Removed " << object << " from inventory." << std::endl;
    }
    else {
        std::cout << "Item not found in inventory." << std::endl;
    }
}

void Characters::Alice::displayInventory() {
    if (inventory.empty()) {
        std::cout << "Your inventory is empty." << std::endl;
    }
    else {
        std::cout << "Inventory:" << std::endl;
        for (const auto& item : inventory) {
            std::cout << "- " << item << std::endl;
        }
    }
}

void Characters::Rabbit::speak1(){
    cout << "The rabbit falls into a rabbit hole." <<endl;
}

void Characters::Rabbit::speak2(){
    cout << "The rabbit rushes back into the area. Frightened by your height, he lets out a small shriek and drops an item, before turning around and running away." <<endl;
}

void::Characters::Rabbit::speak3(){
    cout<<"The rabbit makes another appeareance in front of the building. This time, he seems to think you are his maid." <<endl;
    cout<< "Rabbit: Maid! What are you doing out here? Please fetch my fan from the house, I have seem to misplaced them."<<endl;
}