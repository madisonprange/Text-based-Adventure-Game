#include "AliceinWonderland.h" // Include necessary header files

int main() {
    // Create an instance of AliceinWonderland class
    AliceinWonderland aliceGame;

    // Run the game logic
    aliceGame.run();

    return 0;
}
