#include "Control.h"

Control::~Control()
{
    delete action;
}

Control::Control(Characters::Alice *alice)
{
    action = new Action(alice);
}

std::pair<int, std::string> Control::actionCall()
{
    std::string userInput;
    std::cin.clear();
     std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cout << "What ";
    std::getline(std::cin, userInput); // Read the entire line including spaces
    std::transform(userInput.begin(), userInput.end(), userInput.begin(), ::tolower);

    // Default action is to continue the story
    int actionType = 0;
    std::string actionDetails = "";
    cout<<"hi"<<endl;

    if (userInput.find("go") != std::string::npos) {
        // If the action is movement, return 1 and the destination
        std::string destination;
        std::stringstream ss(userInput);
        ss >> userInput >> userInput >> destination;
        actionType = 1;
        actionDetails = destination;
    }
    else if (userInput.find("pick") != std::string::npos) {
        cout<< "hey" <<endl;
        // If the action is pick up, return 2 and the object
        std::string object;
        std::stringstream ss(userInput);
        ss >> userInput >> userInput >> object;
        if (object == "shovel") {
            action -> handlePickUp(object);
            actionType = 2; // Shovel
        }
        else if (object == "blanket") {
            action -> handlePickUp(object);
            actionType = 6; // Blanket
        }
        actionDetails = object;
    }
    else if (userInput.find("dig") != std::string::npos) {
        actionType = 4;
    }
    else if (userInput.find("sleep") != std::string::npos) {
        actionType = 7;
    }

    // Clear input buffer
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    // Return the action type and details
    return std::make_pair(actionType, actionDetails);
}
