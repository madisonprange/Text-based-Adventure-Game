#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>
#include <iostream>
#include "AliceinWonderland.h" // Include necessary headers
#include "Characters.h"

using namespace std;

class Settings {
public:
    class Field {
    public:
        std::string getDescription();
    };

    class Hole {
    public:
        std::string getDescription1();
        void getDescription2();
    };
    class Forest {
        public:
        void getDescription1();
    };

    class RabbitHouse {
        public:
        void getDescription1();
    };
};

#endif // SETTINGS_H
