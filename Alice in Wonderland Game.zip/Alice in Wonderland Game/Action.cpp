#include "Action.h"

Action::Action(Characters::Alice *alice)
{ this ->alice = alice;
}


int Action::handlePickUp(std::string object)
{
    // Process movement to the specified location
    if (object == "shovel") {
        Object::Shovel shovel;
       
        alice -> addToInventory(object);
        std::cout << "You have picked up a shovel." << std::endl;
        alice -> displayInventory();
        return 2; // Return action type for shovel
    }
    else if (object == "blanket") {
        Object::Blanket blanket;
        alice -> addToInventory(object);
        std::cout << "You have picked up a blanket." << std::endl;
        alice -> displayInventory();
        blanket.desc();
        return 6; // Return action type for blanket
    }
    else {
        return 0; // Return default action type
    }
}
