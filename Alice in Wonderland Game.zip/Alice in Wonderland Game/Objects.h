#ifndef OBJECT_H
#define OBJECT_H

#include <iostream>
#include <string>
#include "AliceinWonderland.h" // Include necessary headers
#include "Characters.h"

class Object {
public:
    class Shovel {
    public:
        void desc();
        std::string actions();
        void digging();
    };

    class Blanket {
    public:
        void desc();
        std::string actions();
        void sleeping();
    };

    class PotionandCake {
    public:
        void drink();
        void eat();
    };

    class Fan {
        public:
        void desc();
        void useFan();
    };
    class waterBottle {
        public:
        void desc();
        void drink();
    };
    class carrotPlush {
        void luckyitem(); //lucky item speech
    };
};

#endif // OBJECT_H
