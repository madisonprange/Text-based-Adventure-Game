#ifndef CHARACTERS_H
#define CHARACTERS_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include "Node.h" // Include necessary headers

class Characters {
public:
    class Alice {
    private:
        Node* node;
        int health;
        std::vector<std::string> inventory;

    public:
        Alice();
        Alice(Node* start);
        bool CanMoveHole();
        void moveHole();
        void aliceHealth(int healthChange);
        int getCurrentHealth() const;
        void addToInventory(const std::string& object);
        void removeFromInventory(const std::string& object);
        void displayInventory();
    };
    class Rabbit {
        public: 
        //fall into the hole method 
        void speak1();
        void speak2();
        void speak3();

        //run in and drop the fan

        //direct Alice to go into the house 


    };
};

#endif // CHARACTERS_H
